//
//  LJBugly.h
//  LJCrash
//
//  Created by Jeffry on 2018/12/28.
//  Copyright © 2018年 Jeffry. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LJBugly : NSObject

+ (void)openBugly;

@end

NS_ASSUME_NONNULL_END
